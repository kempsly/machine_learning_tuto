`python3 -m venv venv`
`source venv/bin/activate`
`pip install flask openai python-dotenv`





